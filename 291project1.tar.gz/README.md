**291 Mini Project 1**

This is an experiment in using python 3 to interface with an sqlite3 database.

*Usage Instructions*
* Move all files to an appropriate folder
* Open the folder in terminal or equivalent of your choice
* Type 'python3 main.py'

*Usage assumptions*
* Must have python3 installed with relevent packages
    * sqlite3, time