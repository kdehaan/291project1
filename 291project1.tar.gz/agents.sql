-- Schema: aid* (text), name (text), pwd (text)
INSERT INTO agents VALUES
    ("a0", "Albert", "0pass"),
    ("a1", "Bernice", "1pass"),
    ("a2", "Conor", "2pass"),
    ("a3", "Diane", "3pass"),
    ("a4", "Eli", "4pass"),
    ("a5", "Freia", "5pass"),
    ("a6", "Gilbert", "6pass"),
    ("a7", "Hanna", "7pass"),
    ("a8", "Isaiah", "8pass"),
    ("a9", "Jill", "9pass"),
    ("a10", "Kevin", "10pass"),
    ("a11", "Lilianne", "11pass"),
    ("a12", "Mary", "12pass"),
    ("a13", "Nicholas", "13pass");

